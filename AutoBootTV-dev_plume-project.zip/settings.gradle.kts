rootProject.name = "AutoBootTV"
include(":app")