# AutoBoot TV — Android TV Auto Launch

Aplikasi Android TV untuk menjalankan aplikasi target secara otomatis setelah perangkat selesai booting.

## Konfigurasi bawaan

- Application ID: `com.autoboot.tvlauncher`
- Target aplikasi: `dev.plume`
- Delay peluncuran: 5 detik
- `minSdk`: 21
- `targetSdk`: 34
- Android Gradle Plugin: 8.3.0
- Gradle: 8.4
- JDK: 17

Pengaturan target package dan delay dibaca dari `SharedPreferences`:
- `target_package`
- `delay_seconds`
- `is_autoboot_enabled`

## Build melalui GitHub Actions

1. Buat repository GitHub baru.
2. Ekstrak seluruh isi ZIP ini, lalu upload/commit semua file dan folder ke root repository.
3. Pastikan workflow tersedia di `.github/workflows/build-apk.yml`.
4. Buka tab **Actions** di repository GitHub.
5. Pilih **Build AutoBoot TV APK**, lalu klik **Run workflow**. Workflow juga berjalan otomatis saat push ke branch `main` atau `master`.
6. Tunggu sampai job berstatus **Success**.
7. Buka hasil workflow, bagian **Artifacts**, lalu unduh `AutoBootTV-APK`.

## Lokasi APK

Setelah build berhasil, file tersedia di artifact GitHub Actions:

- Debug: `app/build/outputs/apk/debug/app-debug.apk`
- Release: `app/build/outputs/apk/release/app-release-unsigned.apk`

APK debug dapat langsung dipasang untuk pengujian. APK release yang dihasilkan workflow ini belum ditandatangani dengan release key.

## Build lokal

Jika Android SDK dan Gradle 8.4 sudah tersedia:

```bash
gradle assembleDebug
gradle assembleRelease
```

## Catatan

- Build workflow menggunakan Gradle 8.4 secara langsung karena ZIP sumber awal tidak menyertakan Gradle Wrapper lengkap.
- Izin khusus Android TV, pembatasan peluncuran aplikasi dari background, dan perilaku boot dapat berbeda menurut versi Android serta firmware perangkat. Keberhasilan build tidak otomatis menjamin auto-launch berjalan pada semua perangkat.
