# AutoBoot TV currently ships without code shrinking.
# Add app-specific keep rules here if shrinking is enabled in the future.
