package com.autoboot.tvlauncher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*

class AutoLaunchService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private var wakeLock: PowerManager.WakeLock? = null

    companion object {
        private const val CHANNEL_ID = "autoboot_channel"
        private const val NOTIFICATION_ID = 1001
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildForegroundNotification("Menyiapkan peluncuran aplikasi..."))

        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AutoBootTV::WakeLock").apply {
            acquire(60 * 1000L) // 1 menit timeout aman
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val targetPackage = intent?.getStringExtra("EXTRA_PACKAGE_NAME") ?: "dev.plume"
        val delaySeconds = intent?.getIntExtra("EXTRA_DELAY_SECONDS", 5) ?: 5

        Log.d("AutoBootTV", "Memulai countdown launch $targetPackage dalam $delaySeconds detik...")

        serviceScope.launch {
            // Delay hitung mundur
            for (i in delaySeconds downTo 1) {
                updateNotification("Membuka aplikasi dalam $i detik...")
                delay(1000L)
            }

            launchTargetApp(targetPackage)
            stopSelf()
        }

        return START_NOT_STICKY
    }

    private fun launchTargetApp(packageName: String) {
        try {
            val pm: PackageManager = packageManager
            // Coba ambil Intent Leanback TV terlebih dahulu
            var launchIntent = pm.getLeanbackLaunchIntentForPackage(packageName)
            if (launchIntent == null) {
                // Fallback ke intent launcher standar
                launchIntent = pm.getLaunchIntentForPackage(packageName)
            }

            if (launchIntent != null) {
                launchIntent.addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
                )
                startActivity(launchIntent)
                Toast.makeText(applicationContext, "AutoBoot TV: Membuka $packageName", Toast.LENGTH_SHORT).show()
                Log.d("AutoBootTV", "Berhasil meluncurkan: $packageName")
            } else {
                Log.e("AutoBootTV", "Aplikasi target tidak ditemukan: $packageName")
                // Buka MainActivity sebagai fallback
                val fallbackIntent = Intent(this, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(fallbackIntent)
            }
        } catch (e: Exception) {
            Log.e("AutoBootTV", "Gagal membuka aplikasi", e)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "AutoBoot TV Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Layanan peluncuran otomatis saat boot TV"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildForegroundNotification(contentText: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("AutoBoot TV")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildForegroundNotification(text))
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        if (wakeLock?.isHeld == true) {
            wakeLock?.release()
        }
        Log.d("AutoBootTV", "AutoLaunchService selesai.")
    }
}