package com.autoboot.tvlauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log

/**
 * BootReceiver: Menerima sinyal BOOT_COMPLETED saat Android TV pertama kali menyala.
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        Log.d("AutoBootTV", "Sinyal Boot diterima: $action")

        val validActions = listOf(
            Intent.ACTION_BOOT_COMPLETED,
            "android.intent.action.QUICKBOOT_POWERON",
            "com.htc.intent.action.QUICKBOOT_POWERON"
        )

        if (action in validActions) {
            val prefs = context.getSharedPreferences("autoboot_prefs", Context.MODE_PRIVATE)
            val isEnabled = prefs.getBoolean("is_autoboot_enabled", true)
            val targetPackage = prefs.getString("target_package", "dev.plume") ?: "dev.plume"

            if (!isEnabled || targetPackage.isEmpty()) {
                Log.d("AutoBootTV", "AutoBoot dinonaktifkan atau target paket kosong.")
                return
            }

            Log.d("AutoBootTV", "Memulai AutoLaunchService untuk target: $targetPackage")
            val serviceIntent = Intent(context, AutoLaunchService::class.java).apply {
                putExtra("EXTRA_PACKAGE_NAME", targetPackage)
                putExtra("EXTRA_DELAY_SECONDS", prefs.getInt("delay_seconds", 5))
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        }
    }
}