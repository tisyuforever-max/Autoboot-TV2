package com.autoboot.tvlauncher

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
// Activity Leanback untuk navigasi remote D-Pad Android TV

class MainActivity : FragmentActivity() {

    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("autoboot_prefs", Context.MODE_PRIVATE)
        setupSettings()
    }

    private fun setupSettings() {
        // Ambil daftar aplikasi TV terinstal
        val installedApps = getInstalledTvApps()
        // Muat ke UI adapter dengan fokus remote D-Pad
    }

    private fun getInstalledTvApps(): List<TvAppModel> {
        val pm = packageManager
        val tvIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        }
        val resolveInfos = pm.queryIntentActivities(tvIntent, 0)
        return resolveInfos.map {
            TvAppModel(
                name = it.loadLabel(pm).toString(),
                packageName = it.activityInfo.packageName,
                icon = it.loadIcon(pm)
            )
        }
    }

    fun saveTargetPackage(packageName: String) {
        prefs.edit().putString("target_package", packageName).apply()
        Toast.makeText(this, "Target aplikasi tersimpan: $packageName", Toast.LENGTH_SHORT).show()
    }

    fun testLaunchApp(packageName: String) {
        val launchIntent = packageManager.getLeanbackLaunchIntentForPackage(packageName)
            ?: packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            startActivity(launchIntent)
        } else {
            Toast.makeText(this, "Aplikasi tidak dapat dibuka", Toast.LENGTH_SHORT).show()
        }
    }
}

data class TvAppModel(
    val name: String,
    val packageName: String,
    val icon: android.graphics.drawable.Drawable
)